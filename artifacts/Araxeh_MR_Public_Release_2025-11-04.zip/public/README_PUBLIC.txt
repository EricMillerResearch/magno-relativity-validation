Araxeh Public Science Release — November 4, 2025

This package summarizes the head-to-head comparison between General Relativity (GR) and Magno-Relativity (MR) on 98 pulsar systems.

Contents:
- MR_GR_Comparison_Summary.pdf
- MR_GR_Comparison_Table.png
- MR_25x_Residuals_Chart.png
- WhitePaper_Results_Section_(Public).pdf
- PressRelease_Araxeh_25x_Physics_Breakthrough.pdf
- LinkedIn_Announcement.txt
- X_Announcement.txt
- MicDrop_Post.txt

No datasets, code, or proprietary equations are included.
