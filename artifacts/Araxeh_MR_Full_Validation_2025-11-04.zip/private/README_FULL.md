# Araxeh MR Full Validation — November 4, 2025

This package contains the full reproducibility bundle for the GR vs MR pulsar comparison.

## Quick Start (3 commands)
```bash
pip install -r requirements.txt
python scripts/run_compare.py --data ./data/raw_atnf_pulsar_dataset.csv --out ./data
python scripts/make_figures.py --in ./data --fig ./figures
```

## Contents
- data/: raw and computed CSVs
- notebooks/: compare_GR_vs_MR.ipynb
- figures/: chi² bar chart, summary graphics
- docs/: white paper section (tex+pdf), investor slide (pdf+png)
- timestamps/: checksum + anchor instructions

License: Proprietary Araxeh License — NDA required.
